package ejercicio3;

public class Main {
	public static void main(String[] args) {
		
		Cars coche1 = new Cars("Audi", "R8", 329);
		
		
	}
}
