package ejercicio4;

public class Autor {

	private String nombre;
	private String nacionalidad;
	private String f_nacimiento;
}
