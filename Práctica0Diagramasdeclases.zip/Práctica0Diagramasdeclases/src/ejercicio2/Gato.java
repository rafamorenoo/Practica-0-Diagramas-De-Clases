package ejercicio2;

public class Gato extends Animal {

	public Gato(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	public void maullar() {
		
	}
	
}
