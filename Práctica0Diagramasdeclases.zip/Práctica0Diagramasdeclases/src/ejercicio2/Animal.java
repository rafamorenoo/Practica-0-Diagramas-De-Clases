package ejercicio2;

public class Animal {

	private int id;

	public Animal(int id) {
		this.id = id;
	}
	
	public void respirar() {
		
	}
	
	
}
