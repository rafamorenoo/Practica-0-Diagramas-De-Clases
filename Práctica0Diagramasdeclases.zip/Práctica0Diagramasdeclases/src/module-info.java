/**
 * 
 */
/**
 * 
 */
module Práctica0Diagramasdeclases {
}