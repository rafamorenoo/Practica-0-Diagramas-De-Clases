package ejercicio2;

public class Main {
	
	public static void main(String[] args) {
		
		Animal gato1 = new Gato(0);
		Animal perro1 = new Perro(0);
		Animal pez1 = new Pez(0);
		
	
		
		
		
		
		
	}
}
