package ejercicio2;

public class Perro extends Animal {

	public Perro(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void ladrar() {
		
	}
 
}
