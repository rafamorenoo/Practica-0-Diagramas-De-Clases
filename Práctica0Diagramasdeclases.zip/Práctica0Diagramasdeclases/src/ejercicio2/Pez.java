package ejercicio2;

public class Pez extends Animal{

	
	public Pez(int id) {
		super(id);
		
	}
	
	public void nadar() {
		
	}

	
	
}
