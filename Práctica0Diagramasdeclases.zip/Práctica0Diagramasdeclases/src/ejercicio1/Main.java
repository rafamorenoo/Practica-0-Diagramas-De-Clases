package ejercicio1;

public class Main {

	public static void main(String[] args) {
		
		Persona persona1 = new Persona("54334587J", "Juan", 25);
		
		
	}
	
}
