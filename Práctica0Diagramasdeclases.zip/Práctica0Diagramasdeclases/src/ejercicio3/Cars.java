package ejercicio3;

public class Cars {

	
	private String nombre;
	private String marca;
	private int VelocidadMax;
	
	
	public Cars(String nombre, String marca, int velocidadMax) {
		
		this.nombre = nombre;
		this.marca = marca;
		VelocidadMax = velocidadMax;
	}
	
	
	public void acelerar() {
		
	}
	
	public void frenar() {
		
	}
	
	public void derrapar() {
		
	}
	
}

