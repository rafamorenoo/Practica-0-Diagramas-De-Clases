package ejercicio1;

public class Persona {

	private String dni;
	private String nombre;
	private int edad;
	
	public Persona(String dni, String nombre, int edad) {
		
		this.dni = dni;
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public void comprar() {
		
	}
	
	public void hablar() {
		
	
	}
	
	public void comer() {
		
	}
	
	
	
	
	
	
}
